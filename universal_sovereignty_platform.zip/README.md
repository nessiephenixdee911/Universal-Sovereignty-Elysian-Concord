
UNIVERSAL SOVEREIGNTY ELYSIAN CONCORD PLATFORM

✔ Doctrine injected verbatim
✔ Dragonchain anchoring hooks
✔ Hyperledger Indy DID hooks
✔ Anonymous yet auditable voting
✔ Legally framed constituent election
✔ Domain‑integrated architecture

Deploy:
- Website → GitHub Pages (HTTPS)
- API → Docker / VPS
